# UrbanOS Water Module

Domain: **Infrastructure → Water** (`/infrastructure/water`).
Pillars: **Water Supply**, **Drain Condition**, **Water Usage**; supporting: **NEWater**, **Water Quality**.
No ML model is used (reason below). Rainfall / flood risk stays in **Flood & Rainfall**.

## What the research found (and did not find)

| Wanted | Result |
|---|---|
| Live drain / canal water-level readings | **No official open feed found.** PUB publishes sensor *locations* only (data.gov.sg GeoJSON). PUB's own map shows levels, but there is no documented open API for them. |
| Reservoir storage levels | **No official open dataset or API found** on data.gov.sg / PUB. |
| Daily or monthly water usage | **Not found.** Only *annual* water-sales tables exist. |
| Annual potable / domestic / non-domestic / NEWater / industrial sales | Found (below). |
| Drinking-water quality | Found, **annual** average + range (below). |

Because of that, the module never shows a drain condition, a reservoir level, a live supply status or a usage forecast
that the data cannot support. Missing data is `null` / `UNAVAILABLE`, never `0` and never "normal".

## Sources actually integrated

All dataset facts below are what the data.gov.sg dataset pages displayed on **30 Sep 2026**.

| Key | Organization | Dataset (ID) | Purpose | Frequency | Coverage | Auth | Status | Component |
|---|---|---|---|---|---|---|---|---|
| `water_sales_annual` | MSE / PUB via SingStat | Water Sales, Annual (`d_9db4902c7a47357441dac7d2806032a5`) | Potable total, domestic, non-domestic, NEWater, industrial sales (million m³) | Annual (page: data last updated 18/05/2026) | 2015–2025; industrial = `na` for 2024–2025 | none required¹ | latest available | Supply, Usage, NEWater |
| `potable_annual` | PUB | Volume of Potable Water sold, Annual (`d_cb1d25dd5cfde21bb9fa704af0e3a962`) | Longer domestic / non-domestic history | Annual (page: updated 20 Apr 2026) | 2008–2025 | none required¹ | historical | Usage |
| `newater_annual` | PUB | Volume of NEWater sold, Annual (`d_2eceeb792a0fca1caa74304d47b46060`) | Long-run NEWater history | Annual | 2007–2025 (confirmed from the live API) | none required¹ | historical | NEWater |
| `drinking_quality` | PUB | Drinking water quality datasets (`d_f397c39929978d3047e0e32430c6763b`) | pH, turbidity, E. coli, conductivity, TDS, colour (+ other parameters) | Annual average & range (page: updated 18 Jun 2026) | 2023–2025 | none required¹ | latest available | Quality |
| `drain_sensors` | PUB | PUB Water Level Sensors (`d_31333fa5cf0834f012d840365b336610`) | Sensor locations for the map (**no readings**); delivered as an **XLSX** file (columns `Station ID`, `Station Name`, `X`, `Y`; 328 stations at last check) | Periodic (page: updated 13 Apr 2026) | static | none required¹ | latest available | Drain (map) |

¹ Code sends `x-api-key` if `DATA_GOV_SG_API_KEY` is set. data.gov.sg has been moving to self-serve API keys, so set it
if you see HTTP 401/403/429 from the Water sources.

Endpoints used: tabular data → `https://data.gov.sg/api/action/datastore_search` (paginated);
Sensor file → `https://api-open.data.gov.sg/v1/public/api/datasets/{id}/poll-download`, then the returned (presigned, 1-hour) file URL. The file is an XLSX workbook, read with the standard library (no extra dependency); GeoJSON is also accepted. Its `X`/`Y` columns are **SVY21 metres (EPSG:3414)**; the file does not declare this, so it was inferred from the magnitudes and confirmed by converting known stations (e.g. 'Happy Ave OD (Jln Gembira)' lands in Geylang). `svy21_to_wgs84()` converts them and matches pyproj to < 1 mm. Sensor ids are the official **Station IDs** (e.g. `CWS186`), which a future `DrainReadingProvider` must use as `sensor_id`. Query strings of download URLs are redacted from all error messages because they contain temporary credentials.

Thresholds for drain classification come from PUB's public "Water Level Sensors & CCTVs" map legend:
0–75 % full = low flood risk, 76–90 % = moderate, 91–100 % = high. Water maps these to
**NORMAL / ELEVATED / HIGH**; **CRITICAL** (> 100 % of reference depth) is this module's own extension, labelled as such.
Quality limits come from PUB's published "Our Drinking Water Quality" table: pH 6.5–9.5, turbidity ≤ 5 NTU,
colour ≤ 15 Hazen, E. coli < 1 cfu/100 mL.

### Not used on purpose
PUB real-time **flood alerts** (released on data.gov.sg in Nov 2025) belong to the Flood & Rainfall module and are not
consumed by Water, to avoid duplicating it.

## Architecture

```
backend/app/infrastructure/water/
  models.py      Pydantic models (WaterReport + sections, DataKind labels)
  sources.py     Acquisition: HTTP client (timeout, retry/backoff on 429/5xx, Retry-After, x-api-key),
                 6h TTL cache with stale-on-error fallback, parsers/validators, WaterSnapshot
  processing.py  Deterministic analytics, drain classification, alerts, forecast-eligibility rule
  agent.py       LangGraph: ingest_water_data → analyze_water → build_report (+ rule-based insights)
  api.py         FastAPI router
coordinator/city_agent.py   Water collected, normalized, cross-domain context, evidence
frontend/src/app/infrastructure/water/   page.tsx, WaterMap.tsx, WaterCharts.tsx
frontend/src/services/api/index.ts       Water types + fetchWaterReport
tests/water/                              93 tests
scripts/inspect_water_sources.py          Verify live field names on your machine
```

Backend-only external calls: the frontend talks to `/api/water/*` only.

### Performance
* The five sources are fetched **concurrently** (total wait ~ the slowest source, not the sum) and applied in catalog order.
* Source data is cached in memory for 6 h (`URBANOS_WATER_CACHE_TTL_S`), with a stale-on-error fallback.
* At server start a background **warm-up** thread builds the first report, so the first page load is ready
  (`URBANOS_WATER_WARMUP=0` disables it; it is always off under pytest). The cache is in memory, so each backend
  restart (including `--reload`) fetches again once.
* The page lazy-loads the map library, so the rest of the page renders first.

### Endpoints
`GET /api/water/report` (full WaterReport) · `/overview` · `/supply` · `/drain` · `/usage` · `/forecast` · `/newater` ·
`/quality` · `/map` (GeoJSON) · `/sources`. All accept `?refresh=true` to bypass the 10-minute report cache.

### WaterReport → City Coordinator
`water_report` is collected next to the other domain reports; `domain_status["water"]` carries key metrics. **Risk is
`UNKNOWN` unless real drain readings exist**, so Water cannot make the city look "low risk". Only three core domains
(environment, traffic, flood) drive coordinator confidence, so adding Water does not change existing behaviour.
A `drain_flood_context` impact (and a `WATER:` recommendation) appears only when real drain readings show HIGH/CRITICAL
drains *and* the Flood module already reports MODERATE+ risk.

## Usage forecast: intentionally not built
The only official usage data is **annual** (≤ 18 points). A chronological train/validation/test split plus a baseline
comparison cannot give trustworthy MAE/RMSE on that. The module requires ≥ 48 observations
(`MIN_OBSERVATIONS_FOR_ML`, e.g. 4 years of monthly data). `/api/water/forecast` returns `available: false` with the
reason. If PUB/SingStat publish monthly usage later, add the data client and the forecaster behind that same rule.

## If PUB ever publishes live drain readings
Implement `DrainReadingProvider.fetch() -> list[DrainReading]` and pass it to `run_water_agent(reading_provider=...)`.
Validation, percentage, NORMAL/ELEVATED/HIGH/CRITICAL classification, trend, alerts, map colouring, coordinator
integration and tests already exist and are exercised with injected readings.

## What has and has not been verified

Verified against the **live APIs** (output of `scripts/inspect_water_sources.py` run on 30 Sep 2026):
* `Water Sales, Annual` (5 rows, wide format, `DataSeries` + one column per year 2015–2025), `Volume of Potable Water
  sold` (36 rows), `Volume of NEWater sold` (19 rows, 2007–2025) and `Drinking water quality` (384 rows) all parse.
* The sensor dataset downloads as an **XLSX** file with `Station ID`, `Station Name`, `X`, `Y` (329 rows incl. header), not GeoJSON.

Verified by tests (93 Water tests; existing suite has no new failures); `tsc --noEmit` and ESLint clean for the new
frontend files.

**Not verified:** `next build` was not run in the build environment (it downloads Google Fonts); run it once locally.
Re-run `python -m scripts.inspect_water_sources` any time to re-check the live structures (the sensor block should show
`valid sensors: 328` or similar, with a name for each).

## Running
```bash
export DATA_GOV_SG_API_KEY=...   # optional/if required by data.gov.sg
python -m pytest tests/water -q
```
