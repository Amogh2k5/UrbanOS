"""UrbanOS Infrastructure domain."""
