"""Inspect the REAL structure of every official source used by the Water module.

Run this once on a machine with internet access:

    python -m scripts.inspect_water_sources

It prints, for each source: HTTP/parse status, record count, field names, sample rows
and the latest data period. The Water module's parsers were written from the dataset
pages' column legends; this script confirms they match the live API responses
(the PUB sensor layer is delivered as an XLSX file; its column names are printed as 'row:' lines).
"""
from __future__ import annotations

import json
import sys

from backend.app.infrastructure.water import sources as src


def show(title: str) -> None:
    print("\n" + "=" * 78 + f"\n{title}\n" + "=" * 78)


def main() -> int:
    client = src.WaterDataClient()
    ok = True
    tabular = [
        ("Water Sales, Annual", src.WATER_SALES_ID, src.parse_water_sales_annual),
        ("Volume of Potable Water sold, Annual", src.POTABLE_ID, src.parse_potable_annual),
        ("Volume of NEWater sold, Annual", src.NEWATER_ID, src.parse_newater_annual),
        ("Drinking water quality datasets", src.QUALITY_ID, src.parse_water_quality),
    ]
    for title, rid, parser in tabular:
        show(f"{title}  [{rid}]")
        try:
            recs = client.get_records(rid).data
            print(f"records: {len(recs)}")
            print("field names:", sorted({k for r in recs for k in r})[:30])
            print("sample:", json.dumps(recs[:2], ensure_ascii=False)[:600])
            parsed = parser(recs)
            print("parsed OK ->", json.dumps(parsed, default=str)[:400])
            if not parsed or (isinstance(parsed, dict) and not any(parsed.values())):
                print("!! parser produced no usable data - field names likely differ"); ok = False
        except Exception as exc:  # noqa: BLE001
            print("FAILED:", exc); ok = False

    show(f"PUB Water Level Sensors  [{src.SENSORS_ID}]")
    try:
        layer = client.get_sensor_layer(src.SENSORS_ID).data
        print("file type:", layer["kind"])
        if layer["kind"] == "xlsx":
            rows = layer["rows"]
            print("rows:", len(rows))
            for r in rows[:4]:
                print("  row:", r)
        else:
            feats = layer["data"].get("features", [])
            print("features:", len(feats))
            if feats:
                print("first feature:", json.dumps(feats[0], ensure_ascii=False)[:800])
        sensors, invalid = src.parse_sensor_layer(layer)
        named = sum(1 for s in sensors if s.name)
        print(f"valid sensors: {len(sensors)}  invalid: {invalid}  with a name: {named}")
        if sensors:
            print("first sensor:", sensors[0])
        else:
            print("!! No sensors parsed"); ok = False
        if sensors and named == 0:
            print("!! No sensor names parsed - send me the 'row:' lines above"); ok = False
    except Exception as exc:  # noqa: BLE001
        print("FAILED:", exc); ok = False

    print("\nRESULT:", "all sources parsed" if ok else "attention needed (see '!!' / FAILED above)")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
