"""UrbanOS Safety domain."""
