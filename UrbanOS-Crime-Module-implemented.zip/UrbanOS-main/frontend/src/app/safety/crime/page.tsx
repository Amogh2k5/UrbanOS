/* eslint-disable @typescript-eslint/no-explicit-any */
"use client";

import { useEffect, useMemo, useState } from "react";
import {
  AlertTriangle,
  BarChart3,
  Database,
  MapPin,
  Shield,
  Users,
  WalletCards,
  RefreshCw,
  Info,
} from "lucide-react";
import {
  fetchCrimeReport,
  CrimeReport,
  CrimeSeries,
  CrimeArrestSeries,
  ScamType,
} from "@/services/api";

const years = ["2021", "2022", "2023", "2024", "2025"];

function fmt(value: number | null | undefined) {
  if (value === null || value === undefined) return "—";
  return new Intl.NumberFormat("en-SG", { maximumFractionDigits: 0 }).format(value);
}

function fmtMoney(value: number | null | undefined) {
  if (value === null || value === undefined) return "—";
  return `S$${value.toFixed(1)}M`;
}

function Card({ title, value, icon: Icon, note }: any) {
  return (
    <div className="glass-panel rounded-xl border border-gray-800/60 p-5">
      <div className="flex items-center justify-between">
        <span className="text-xs tracking-widest text-gray-500 font-bold">{title}</span>
        <Icon size={18} className="text-cyan-400" />
      </div>
      <div className="mt-3 text-2xl font-mono font-bold text-white">{value}</div>
      {note && <div className="mt-1 text-xs text-gray-500">{note}</div>}
    </div>
  );
}

function TrendTable({ rows }: { rows: CrimeSeries[] }) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead>
          <tr className="text-left text-xs uppercase tracking-wider text-gray-500 border-b border-gray-800">
            <th className="py-3 pr-4">Category</th>
            {years.map((y) => <th key={y} className="py-3 px-3 text-right">{y}</th>)}
          </tr>
        </thead>
        <tbody>
          {rows.map((row) => (
            <tr key={row.name} className="border-b border-gray-900 last:border-0">
              <td className="py-3 pr-4 text-gray-200">{row.name}</td>
              {years.map((y) => (
                <td key={y} className="py-3 px-3 text-right font-mono text-gray-300">
                  {fmt(row.values[y])}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function BarList({ rows }: { rows: CrimeSeries[] }) {
  const max = Math.max(...rows.map((r) => Number(r.values["2025"] ?? 0)), 1);
  return (
    <div className="space-y-4">
      {rows.map((row) => {
        const value = Number(row.values["2025"] ?? 0);
        return (
          <div key={row.name}>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-gray-300">{row.name}</span>
              <span className="font-mono text-cyan-300">{fmt(value)}</span>
            </div>
            <div className="h-2 rounded bg-gray-800 overflow-hidden">
              <div
                className="h-full bg-cyan-500/70 rounded"
                style={{ width: `${Math.max((value / max) * 100, value ? 2 : 0)}%` }}
              />
            </div>
          </div>
        );
      })}
    </div>
  );
}

function ScamTable({ rows }: { rows: ScamType[] }) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead>
          <tr className="text-left text-xs uppercase tracking-wider text-gray-500 border-b border-gray-800">
            <th className="py-3 pr-4">Scam type</th>
            <th className="py-3 px-3 text-right">Cases</th>
            <th className="py-3 px-3 text-right">Loss</th>
            <th className="py-3 px-3 text-right">Avg. loss</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((row) => (
            <tr key={row.name} className="border-b border-gray-900 last:border-0">
              <td className="py-3 pr-4 text-gray-200">{row.name}</td>
              <td className="py-3 px-3 text-right font-mono text-gray-300">{fmt(row.cases)}</td>
              <td className="py-3 px-3 text-right font-mono text-amber-300">{fmtMoney(row.loss_sgd_million)}</td>
              <td className="py-3 px-3 text-right font-mono text-gray-300">
                {row.average_loss_sgd == null ? "—" : `S$${fmt(row.average_loss_sgd)}`}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function ArrestTable({ rows }: { rows: CrimeArrestSeries[] }) {
  const visible = rows.filter((r) => r.values["2025"] != null);
  return (
    <div className="overflow-x-auto max-h-[420px] overflow-y-auto">
      <table className="w-full text-sm">
        <thead className="sticky top-0 bg-slate-950">
          <tr className="text-left text-xs uppercase tracking-wider text-gray-500 border-b border-gray-800">
            <th className="py-3 pr-4">Selected offence</th>
            {years.map((y) => <th key={y} className="py-3 px-3 text-right">{y}</th>)}
          </tr>
        </thead>
        <tbody>
          {visible.map((row) => (
            <tr key={row.offence} className="border-b border-gray-900">
              <td className="py-3 pr-4 text-gray-200">{row.offence}</td>
              {years.map((y) => (
                <td key={y} className="py-3 px-3 text-right font-mono text-gray-300">{fmt(row.values[y])}</td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default function CrimePage() {
  const [report, setReport] = useState<CrimeReport | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = async () => {
    setLoading(true);
    try {
      const data = await fetchCrimeReport();
      setReport(data);
      setError(null);
    } catch (e: any) {
      setError(e?.message || "Crime data unavailable");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const offenceRows = useMemo(
    () => report?.major_offences ?? [],
    [report]
  );

  const npc2025 = useMemo(() => {
    return (report?.npc_geography ?? [])
      .filter((r) => r.values["2025"] != null)
      .sort((a, b) => Number(b.values["2025"] ?? 0) - Number(a.values["2025"] ?? 0))
      .slice(0, 20);
  }, [report]);

  return (
    <div className="h-full overflow-y-auto bg-[var(--color-background)] text-[var(--color-foreground)] p-4 md:p-6 lg:p-8">
      <div className="max-w-[1800px] mx-auto">
        <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
          <div>
            <div className="flex items-center gap-3">
              <Shield size={25} className="text-cyan-400" />
              <h1 className="text-2xl font-heading text-cyan-300">Safety – Crime</h1>
            </div>
            <p className="text-sm text-gray-500 mt-2">
              Official Singapore crime intelligence • annual/historical statistics, not a live incident feed
            </p>
          </div>
          <button
            onClick={load}
            disabled={loading}
            className="px-3 py-2 rounded-lg border border-gray-700 text-xs text-gray-300 hover:bg-gray-800 flex items-center gap-2"
          >
            <RefreshCw size={14} className={loading ? "animate-spin" : ""} /> Refresh
          </button>
        </div>

        {loading && !report && (
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {[1, 2, 3, 4].map((x) => (
              <div key={x} className="h-32 rounded-xl bg-gray-900 animate-pulse border border-gray-800" />
            ))}
          </div>
        )}

        {error && (
          <div className="mb-6 rounded-xl border border-red-500/30 bg-red-950/20 p-4 text-sm text-red-300">
            <div className="flex items-center gap-2 font-semibold"><AlertTriangle size={16} /> Data source unavailable</div>
            <div className="mt-1 text-red-200/70">{error}</div>
          </div>
        )}

        {report && (
          <>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
              <Card title="PHYSICAL CRIME · 2025" value={fmt(report.total_physical_crime_2025)} icon={Shield} note="Reported physical crime cases" />
              <Card title="SCAMS + CYBERCRIME · 2025" value={fmt(report.total_scams_cybercrime_2025)} icon={AlertTriangle} note="Combined reported cases" />
              <Card title="SCAM LOSSES · 2025" value={fmtMoney(report.scam_types.reduce((s, x) => s + (x.loss_sgd_million ?? 0), 0))} icon={WalletCards} note="Top-10 scam types in SPF brief" />
              <Card title="PHYSICAL CRIME RATE" value={report.physical_crime_rate_2025 == null ? "—" : `${fmt(report.physical_crime_rate_2025)}/100k`} icon={Users} note="2025 official rate" />
            </div>

            <div className="mb-6 rounded-xl border border-cyan-500/20 bg-cyan-950/10 p-4 text-sm text-gray-300">
              <div className="flex items-start gap-3">
                <Info size={17} className="text-cyan-400 mt-0.5 shrink-0" />
                <div>
                  <div className="font-semibold text-cyan-300">Data period & provenance</div>
                  <div className="mt-1">{report.data_period}</div>
                  <div className="mt-1 text-xs text-gray-500">
                    Status: {report.source_status.toUpperCase()} • {report.geographic_scope}
                  </div>
                </div>
              </div>
            </div>

            <section className="grid grid-cols-1 xl:grid-cols-2 gap-6 mb-6">
              <div className="glass-panel rounded-xl border border-gray-800/60 p-5">
                <div className="flex items-center gap-2 mb-5">
                  <BarChart3 size={18} className="text-cyan-400" />
                  <h2 className="font-bold text-white">Crime Categories</h2>
                </div>
                <BarList rows={report.overview.filter((r) => r.values["2025"] != null)} />
              </div>

              <div className="glass-panel rounded-xl border border-gray-800/60 p-5">
                <div className="flex items-center gap-2 mb-5">
                  <BarChart3 size={18} className="text-cyan-400" />
                  <h2 className="font-bold text-white">Major Offences · 2025</h2>
                </div>
                <BarList rows={offenceRows.filter((r) => r.values["2025"] != null).slice(0, 10)} />
              </div>
            </section>

            <section className="glass-panel rounded-xl border border-gray-800/60 p-5 mb-6">
              <div className="flex items-center gap-2 mb-4">
                <BarChart3 size={18} className="text-cyan-400" />
                <h2 className="font-bold text-white">Historical Crime Trends</h2>
              </div>
              <TrendTable rows={report.overview} />
            </section>

            <section className="glass-panel rounded-xl border border-gray-800/60 p-5 mb-6">
              <div className="flex items-center gap-2 mb-2">
                <WalletCards size={18} className="text-amber-300" />
                <h2 className="font-bold text-white">Scams & Cybercrime</h2>
              </div>
              <p className="text-xs text-gray-500 mb-4">
                Top-10 scam categories and losses are from the official SPF Annual Scam and Cybercrime Brief 2025 infographic.
              </p>
              <ScamTable rows={report.scam_types} />
            </section>

            <section className="glass-panel rounded-xl border border-gray-800/60 p-5 mb-6">
              <div className="flex items-center gap-2 mb-4">
                <Users size={18} className="text-cyan-400" />
                <h2 className="font-bold text-white">Arrests · Selected Major Offences</h2>
              </div>
              <p className="text-xs text-gray-500 mb-4">
                Source dataset contains persons arrested by selected offence, sex and broad age group. The dashboard displays the source's total-person offence rows.
              </p>
              <ArrestTable rows={report.arrests} />
            </section>

            <section className="glass-panel rounded-xl border border-gray-800/60 p-5 mb-6">
              <div className="flex items-center gap-2 mb-2">
                <MapPin size={18} className="text-cyan-400" />
                <h2 className="font-bold text-white">Geographic Analysis · NPC</h2>
              </div>
              <p className="text-xs text-gray-500 mb-4">
                Official NPC data is for cases with known locations. It provides neighbourhood-police-centre geography but no latitude/longitude, so this module deliberately uses a table rather than a fabricated heatmap.
              </p>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="text-left text-xs uppercase tracking-wider text-gray-500 border-b border-gray-800">
                      <th className="py-3 pr-4">Source geography</th>
                      <th className="py-3 px-3 text-right">2025</th>
                      <th className="py-3 px-3 text-right">2024</th>
                      <th className="py-3 px-3 text-right">2023</th>
                    </tr>
                  </thead>
                  <tbody>
                    {npc2025.map((row) => (
                      <tr key={row.npc} className="border-b border-gray-900">
                        <td className="py-3 pr-4 text-gray-200">{row.npc}</td>
                        <td className="py-3 px-3 text-right font-mono text-gray-300">{fmt(row.values["2025"])}</td>
                        <td className="py-3 px-3 text-right font-mono text-gray-300">{fmt(row.values["2024"])}</td>
                        <td className="py-3 px-3 text-right font-mono text-gray-300">{fmt(row.values["2023"])}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </section>

            <section className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="glass-panel rounded-xl border border-gray-800/60 p-5">
                <h2 className="font-bold text-white mb-3">Official Sources</h2>
                <ul className="space-y-2 text-xs text-gray-400">
                  {report.data_sources.map((source) => <li key={source}>• {source}</li>)}
                </ul>
              </div>
              <div className="glass-panel rounded-xl border border-gray-800/60 p-5">
                <h2 className="font-bold text-white mb-3">Limitations & Warnings</h2>
                <ul className="space-y-2 text-xs text-gray-400">
                  {[...report.limitations, ...report.warnings, ...report.errors].map((item, i) => <li key={`${i}-${item}`}>• {item}</li>)}
                </ul>
              </div>
            </section>
          </>
        )}
      </div>
    </div>
  );
}
