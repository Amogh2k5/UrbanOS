# UrbanOS Safety → Crime Module

## 1. Sources discovered

### Machine-readable official sources
All four datasets below are published through data.gov.sg by SINGSTAT and identify the Singapore Police Force as the source:

- **Crime Cases Recorded, Annual** — dataset `d_ca0b908cf06a267ca06acbd5feb4465c`; 2020–2025.
- **Cases Recorded For Selected Major Offences, Annual** — dataset `d_02d07531b84cd0cf2cf901fc1bf5d395`; 2011–2025.
- **Persons Arrested For Selected Major Offences By Sex And Broad Age Group, Annual** — dataset `d_08433c469bbe2768daf9e2b86217991d`; 2011–2025.
- **Selected Major Offences Recorded By Neighbourhood Police Centre (NPC), Annual** — dataset `d_5767147db6e5b4c4cfa874db132fef39`; 2011–2025 and cases with known locations.

### Official SPF publication
- **Annual Scam and Cybercrime Brief 2025 infographic** — official SPF PDF. It provides 2025 top scam categories, case counts, losses and average loss values used by the dashboard.

## 2. Sources successfully tested

The data.gov.sg datastore API endpoint was tested against the crime-cases and major-offences datasets and returned successful JSON records. The dataset pages/API documentation also expose the same datastore query pattern for the arrests and NPC datasets.

The SPF 2025 scam publication was verified as an official SPF publication. Its 2025 infographic values are used as source-attributed static release data because the publication is a PDF rather than a machine-readable crime dataset.

## 3. APIs/datasets actually used

Runtime API:
`https://data.gov.sg/api/action/datastore_search?resource_id=<dataset_id>`

Dataset IDs:
- `d_ca0b908cf06a267ca06acbd5feb4465c`
- `d_02d07531b84cd0cf2cf901fc1bf5d395`
- `d_08433c469bbe2768daf9e2b86217991d`
- `d_5767147db6e5b4c4cfa874db132fef39`

Static official source:
- SPF Annual Scam and Cybercrime Brief 2025 infographic.

## 4. Features implemented

- `/api/crime/report` backend endpoint.
- Official data.gov.sg API client with timeout, HTTP failure handling, 429/rate-limit handling and optional `DATA_GOV_SG_API_KEY`.
- Deterministic normalization of annual crime categories and major offences.
- Historical trends.
- Major-offence overview.
- Scam and cybercrime overview.
- Top-10 2025 scam categories, cases, losses and average losses from SPF's official 2025 infographic.
- Selected-offence arrest table.
- NPC geographic analysis using official cases-with-known-locations data.
- Explicit source period/provenance and limitation display.
- Loading, error and empty-safe handling.
- Crime Agent implemented with LangGraph and deterministic processing; no ML.
- City Coordinator integration as a historical intelligence domain. Crime is not converted into a live risk score or active incident count.
- Safety navigation updated with Crime.

## 5. Features that could not be implemented and why

- **Live crime incident feed:** no verified public operational SPF crime-incident API was found in the sources used.
- **Crime heatmap with coordinates:** the official NPC dataset provides neighbourhood-police-centre geography for cases with known locations but does not provide latitude/longitude in the dataset; coordinates were therefore not invented.
- **Real-time crime prediction:** no prediction task was required or justified by the discovered public data, so no ML was added.
- **Full live scam-category feed:** the verified detailed 2025 scam categories/losses are in an SPF PDF publication rather than a machine-readable API; the module therefore treats those details as a dated 2025 release, not live data.

## 6. Files created/modified

Created:
- `backend/app/safety/crime/__init__.py`
- `backend/app/safety/crime/models.py`
- `backend/app/safety/crime/data.py`
- `backend/app/safety/crime/processing.py`
- `backend/app/safety/crime/agent.py`
- `backend/app/safety/crime/api.py`
- `frontend/src/app/safety/crime/page.tsx`
- `tests/crime/test_processing.py`
- `tests/crime/test_agent.py`
- `docs/CRIME_MODULE.md`

Modified for integration:
- `backend/app/main.py`
- `coordinator/city_agent.py`
- `frontend/src/services/api/index.ts`
- `frontend/src/components/common/TopNav.tsx`

No unrelated domain implementation was intentionally changed.

## 7. Tests and verification results

The implementation includes unit tests for:
- deterministic transformation of official-style dataset records;
- preservation of missing values as `None` rather than zero;
- Crime Agent report construction using a mocked official-data snapshot.

Before deployment, run the backend test suite and frontend lint/build in the repository environment. The module itself does not require an additional frontend package.

## 8. Known data limitations

- The module is historical/annual, not an operational live crime feed.
- Data.gov.sg datasets are updated annually and their periods differ by dataset.
- From 2022, SPF crime reporting uses Physical Crimes and Scams & Cybercrimes categories instead of Overall Crime, so older aggregate comparisons require care.
- NPC records are limited to cases with known locations.
- No coordinates are assumed for NPC records.
- Scam detail is specifically the 2025 SPF publication and should be refreshed when SPF publishes a later annual brief.
- API rate limits and source availability can temporarily make individual datasets unavailable; the backend reports those failures rather than converting them to zero.
