"""Fire/Safety domain."""
